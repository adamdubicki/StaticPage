# StaticPage
A page to show previous work and pages

## Template
Template was downloaded from https://startbootstrap.com.